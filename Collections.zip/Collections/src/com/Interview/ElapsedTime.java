package com.Interview;

import java.util.Scanner;

public class ElapsedTime {

	public static void main(String[] args) {
		
		long startTime;
		long endTime;
		double Time;
		
		startTime = System.currentTimeMillis();
		
		//doing some operations
		//read and print your name
		
		System.out.println("Enter Your Name");
		
		Scanner sc=new Scanner(System.in);
		
		String name=sc.nextLine();
		
		System.out.println("Thanks "+name+ "!");
		
		endTime=System.currentTimeMillis();
		
		Time=(endTime-startTime)/1000.0;
		System.out.println("ElapsedTime is "+Time);
	}

}
