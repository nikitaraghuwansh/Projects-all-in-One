package com.networking;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class IPAddress {

	public static void main(String[] args) {
	
		InetAddress inet = null;
		try {
			inet = InetAddress.getByName("www.google.com");
		} catch (UnknownHostException e) {
			
			e.printStackTrace();
		}
		
		System.out.println(inet);
	}

}
