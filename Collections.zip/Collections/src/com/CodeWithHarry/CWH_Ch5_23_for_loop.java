package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch5_23_for_loop {

	public static void main(String[] args) {

		int a;
		for (a = 1; a <= 10; a++) {
			System.out.println(a);
		}
//-------------------------------------------------------------------------------
		// Quick Quig= WAP to Print first n odd numbers using a for loop
		//2i= Even Number = 0,2,4,6,8
		//2i+1=odd number = 1,3,5,7,9
		int n = 5;
		for(int i=0;i<n; i++)
		{
			System.out.println(2*i+1);	
		}
		
//---------------------------------------------------------------------------------
		int y;
		System.out.println("This is a Decrement:");
		for(y=5; y>0; y--)
		{
			System.out.println(y);
		}
			}

}
