package com.Interview;

import java.util.Scanner;

public class PrintTable {

	public static void main(String[] args) {

		int number;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Any Number ");

		number = sc.nextInt();
		System.out.println("Table of  " + number + "  is");

		for (int i = 1; i <= 10; i++) {
			System.out.println(number * i);
		}
	}

}
