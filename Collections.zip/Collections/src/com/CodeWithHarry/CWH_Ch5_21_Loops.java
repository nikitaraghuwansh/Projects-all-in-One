package com.CodeWithHarry;

public class CWH_Ch5_21_Loops {

	public static void main(String[] args) {
		/*int i = 1;
		while (i <= 3) {
			System.out.println(i);
			i++;
		}
		System.out.println("Finish Running While Loop!");
		*/

//------------------------------------------------------------------------------------------------
		// Quick Quig= WAP to print natural Numbers from 100 to 200
		int i = 100;
		while (i <= 200) {
			System.out.println(i);
			i++;
		}
		System.out.println("Finish Running While Loop!");

		
	}

}
