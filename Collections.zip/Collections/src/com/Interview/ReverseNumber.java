package com.Interview;

import java.util.Scanner;

public class ReverseNumber {

	public static void main(String[] args) {

		int number, reverse;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Enter Your Number:");
		
		number = sc.nextInt();

		while (number > 0) {
			
			reverse = number % 10;
			System.out.print(reverse);
			number = number / 10;

		}

	}

}
