package com.CodeWithHarry;

public class CWH_Ch3_15_PracticeSet3 {

	public static void main(String[] args) {

		// Question 1= write a java program to convert a string to lowerCase

		String name = "NiKITA Raghuwanshi";
		System.out.println(name.toLowerCase());
		

		// Qestion 2- String text change to _ (underscore)

		String Text = "This is a java programing language";

		Text = Text.replace(" ", "_");
		System.out.println(Text);
		

		// Question 3=

		String letter = "Dear <|name|>, thanks a lot";

		letter.replace("<|name|>", "Nikita");
		System.out.println(letter);

		letter = "Dear <|name|>, thanks a lot";

		letter = letter.replace("<|name|>", "Nikita");
		System.out.println(letter);
		

		// Question 4
		String mystring = "This string contains   double  and triple space";

		System.out.println(mystring.indexOf("  "));
		System.out.println(mystring.indexOf("    ")); // isme yaha check kiya ki isme agar triple space hogi to index no -1 dega
		
		//Question 5 is String ko ek letter ki tarah print karna h
		
		String letter2="Dear Harry,\n\t This java course is nice,\n\tThanks";
		System.out.println(letter2);

	}

}
