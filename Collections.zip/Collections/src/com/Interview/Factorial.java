package com.Interview;

import java.util.Scanner;

public class Factorial {
	/*Java program for Factorial - to find Factorial of a Number.*/

	public static void main(String[] args) {
		
		int num;
		long factorial;
		
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Your Number:  ");
		num=sc.nextInt();
		
		factorial =1;
		for(int i=num; i>=1;i--) {
			
			factorial*=i;
			
			
		}
		System.out.println("Factorial of is:"+factorial);
	}

}
