package com.CodeWithHarry;

import java.util.Scanner;
public class HUserInput2 {

	public static void main(String[] args) {
	
		int sum ;
	 System.out.println("Taking Input From the user");

	 Scanner sc = new Scanner(System.in); //Scanner Object

	 System.out.println("Enter first Number");
	 int a =sc.nextInt();
	 
	 System.out.println("Enter the second Number");
	 int b =sc.nextInt();
	 sum=a+b;
	 
	 System.out.println("The sum of these Number is : "+sum);
	 
	// System.out.println(sc.hasNextInt());
	 
String str=sc.next();
System.out.println(str);
// next() method me sirf ek word ko read karta h aage agar space hoti h to read nhi karta
//Example= mene nikita raghuwanshi likha to sirf nikita ko read karega

String str2=sc.nextLine(); //nextLine() method puri line ko read karta h
System.out.println(str2);

	
	}

}
