package com.CodeWithHarry;
import java.util.Scanner;

public class CWH_Ch1_PS7 {
	
	// CWH_cH1_PS7- code with harry chapter 1 practice set class #7
	
	public static void main(String[] args) {

		// Question 1- Three number sum
		int Number1,Number2,Number3,sum;
		
		Number1=21;
		Number2=32;
		Number3=43;
		
		sum=Number1+Number2+Number3;
		
		System.out.println(sum);
		//-----------------------------------------------------------------------------------------

		//Question 2= cgpa calculate karna h
		
		float subject1 = 45;
		float subject2 = 95;
		float subject3 = 48;
		float total = (subject1+subject2+subject3)/3;
		System.out.println(total);
		
		float cgpa=total/10;
		
		System.out.println(cgpa);
	//-------------------------------------------------------------------------------------------------
		
		//Qurstion 3- ek java program likhana h jo ki user se uska name puche or fir ye print karke de "Hello UserName Have a good day"
		
		 String name;
		Scanner sc=new Scanner(System.in);
		System.out.println("What is Your Name");
		
		name=sc.nextLine();
		
		//tarika 1
		System.out.print("Hello "+name);
		System.out.print(" ");
		System.out.println("Have a Good Day");
		
		//tarika2 
		System.out.println("Hello " +name+ " Have a Good Day");
		
		//---------------------------------------------------------------------------------------------------
		
		//Question 4- Write a program to convert kilometers to miles
		// miles=0.621371, 1 km = 0.621371 miles
		//10 km*0.621371
		
		double km,miles;
		
		System.out.println("Enter Kilometers");
		
		km=sc.nextDouble();
		
		miles=(km*0.621371);
		
		System.out.println("Miles is " +miles);
	//---------------------------------------------------------------------------------------------------------
		
		//Question 5- Wrire a program to detact karna h ki jo number user ne input kiya h wo number interger h ya nhi
		
		
		System.out.println("Enter the Number");
				
		System.out.println(sc.hasNextInt());
		// isme aisa ho raha h ki jese mene Integer ki jagah String de di to False print karega
	}

}
