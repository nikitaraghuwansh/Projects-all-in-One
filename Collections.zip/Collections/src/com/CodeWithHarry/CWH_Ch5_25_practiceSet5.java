package com.CodeWithHarry;

public class CWH_Ch5_25_practiceSet5 {

	public static void main(String[] args) {

		int n = 4;
		for (int i = n; i > 0; i--) {

			for (int j = 0; j < i; j++) {

				System.out.print("*");
			}
			System.out.print("\n");

		}
//-----------------------------------------------------------------------------
		
		//Question 2
		int sum=0;
		int b=4;
		for(int a=0; a<b; a++) {
			sum =sum + (2*a);
		}
		System.out.println("sum no of even number:");
		System.out.println(sum);
//-----------------------------------------------------------------------------
		/*
		//Question 3
		int x=5;
		for(int y=1; y<=10; y++)
		{
			System.out.printf("%d X %d =%d ",x,y, x*y);	
		}*/
//-------------------------------------------------------------------------------
		//Question 4
		int x = 10;
		for(int y=10; y>=1; y--)
		{
		System.out.printf("%d X %d =%d\n ",x,y, x*y);	
		//System.out.println(y);
		}
//----------------------------------------------------------------------------------		
		//Question 5 Fectorial no
		
	}
}
