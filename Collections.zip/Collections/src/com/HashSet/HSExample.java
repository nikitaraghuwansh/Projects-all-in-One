package com.HashSet;

import java.util.HashSet;
import java.util.Iterator;


public class HSExample {

	public static void main(String[] args) {

		// HashSet Create

		HashSet<Integer> sh = new HashSet<Integer>();

		// Insert value

		sh.add(1);
		sh.add(2);
		sh.add(3);
		sh.add(4);
		sh.add(3);
		sh.add(1);

		// element search=contains

		if (sh.contains(1)) {
			System.out.println("sh contain 1");
		} else {
			System.out.println(" does not contain 1");
		}

		// element remove=.remove
		sh.remove(1);

		if (!sh.contains(1)) {
			System.out.println("does not contain 1 -we delete 1");
		}

		else {
			System.out.println("sh contains 1");
		}

		// size=.size()
	System.out.println("element size"+sh.size());
	
	
	//Iterator
	//hasNext().next()
	
	Iterator it = sh.iterator();
	while(it.hasNext())
	{
		System.out.println(it.next());
	}
}
	
}
