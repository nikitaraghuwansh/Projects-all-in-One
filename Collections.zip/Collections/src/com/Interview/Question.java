package com.Interview;

import java.util.Scanner;

public class Question {
	public static void main(String args[]) {

//  Ques-1-Can you write the logic to swap two numbers?
		int a,b;
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter a value ");
		a=sc.nextInt();
		
		
		System.out.println("Enter b value ");
		b=sc.nextInt();
		
		
		System.out.println("After");
		System.out.println("a = "+a);
		System.out.println("b = "+b); 
		
		a = a + b; // 40;
		b = a - b; // 40-30=10;
		a = a - b; // 40-10=30;
		System.out.println("Before");
		System.out.println("a = "+a);
		System.out.println("b = "+b);
	}

}
