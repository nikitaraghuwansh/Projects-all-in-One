package com.CodeWithHarry;

public class HQuestion4 {

	public static void main(String[] args) {

		System.out.println(" The sum of these nubers is");
 int Num1 = 12;
 int Num2 = 43;
 int Num3 = 32;
 int sum=Num1+Num2+Num3;
 System.out.println("The sum are : "+sum);

	}

}
