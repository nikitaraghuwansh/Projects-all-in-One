package com.awtExample;
import java.awt.*;
public class AWTExample {
	//constractor
	
	public AWTExample()
	{
	
	Frame fm1=new Frame("Java Developer..");
	TextField text1,text2;
	text1 =new TextField("Software Developer ");
	text1.setBounds(47,243,122,70);
	text2 =new TextField("Backend Developer");
	text2.setBounds(48,242,123,76);
	
	fm1.add(text1);
	fm1.add(text2);
	fm1.setSize(454,846);
	fm1.setVisible(true);
	fm1.setLayout(null);

	
	}


	public static void main(String args[])
	{
				
	AWTExample a=new AWTExample(); //Create Object

	}
	}


