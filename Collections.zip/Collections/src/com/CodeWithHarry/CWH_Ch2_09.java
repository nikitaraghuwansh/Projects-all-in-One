package com.CodeWithHarry;

public class CWH_Ch2_09 {

	public static void main(String[] args) {

		// Precedence & Associativity

		// Normaly= matlb ki jese 4*3 - 32/2 me pahale 4*3 ka multiplication hoga uske
		// baad 32/2 hoga or fir - hoga jo bada ho wo pahale kam karega
		// jese * sabse bada fir + / -

		int a = 4 * 3 - 32 / 2;
		/*
		 * a =12-16;
		 * 
		 * a=-4
		 */
		System.out.println(a);

		// Precedence= me Left-to-Right hota h agar unki Precedence same hogi to, nhi to
		// jiski precedence jyeda hogi wo pahale kamm karega
		// jese * / ki precendence 12 h to 3*2 - 3/4 me pahale 3*2 hoga kyuki
		// Left-To-Right

		// Associativity matlb jese * / ki associativity 12 hoti h

		int b = 40 * 3 - 32 / 2;

		/*
		 * b=120-16 b=104
		 * 
		 * 
		 */
		System.out.println(b);

		// Quick Quiz
		int x = 8;
		int y = 1;
		int k = x * y / 2; // Left-To-Right hoga mtlb pahale * hoga

		System.out.println(k);

		  int d=1;
		  int e=4;
		  int f=5;
		  int z= e*e - (4*d*f)/(2*d);
		  System.out.println(z);
	}

}
