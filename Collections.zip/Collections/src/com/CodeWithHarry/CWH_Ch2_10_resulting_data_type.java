package com.CodeWithHarry;

public class CWH_Ch2_10_resulting_data_type {

	public static void main(String[] args) {
		byte a=127;
		int b=10;
		short c=2345;
		long d=202020;
		float e=2.4f;
		double f=2.43;
		
		float x=a+e;
		System.out.println(x);
		//-------------------------------------------------------------------------
		
		//increment and Decrement Operator
		int i=30;
		 System.out.println(i);
		 System.out.println(i++);
		 System.out.println(i);
		 System.out.println(++i);
		 System.out.println(i);
		 // 30,30,31,32,32
		 
		// Quick Quis: what will be the value of the floowing expression(x)
		 int y=7;
		 int v=++y*8;
		 System.out.println(v);
		 //------------------------------------------------------------------------------
		 
		 //charecter me increment and decrement
		 char ch='a';
		
		 System.out.println(++ch);
		 
		 
		 
	}

}
