package Thread;
public class ThreadExample1 extends Thread
{

public void run()
{
for(int i=0;i<=100;i++)
{
System.out.println("I is="+i);
}

}

public static void main(String str[])
{

ThreadExample1 obj1=new ThreadExample1();
Thread t1=new Thread(obj1);

Thread t2=new Thread(obj1);
Thread t3=new Thread(obj1);
Thread t4=new Thread(obj1);
t1.start();
t1.setName("Thread1");
t2.start();
t2.setName("Thread2");
t3.start();
t3.setName("Thread3");
t4.start();
t4.setName("Thread4");

}
}