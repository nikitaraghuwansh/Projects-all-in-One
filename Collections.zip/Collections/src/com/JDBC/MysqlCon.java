package com.JDBC;

import java.sql.*;

public class MysqlCon {

	public static void main(String[] args) {

		Connection con = null;
		// Statement stmt = null;
		// ResultSet rs = null;

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Grafix1", "root", "1234");

			Statement stmt = con.createStatement();

			String query = "select * from student";

			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				System.out.println(rs.getString(1));
				System.out.println(rs.getString(2));

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			try {
				con.close();
			} catch (SQLException e) {

				e.printStackTrace();
			}

		}

	}

}
