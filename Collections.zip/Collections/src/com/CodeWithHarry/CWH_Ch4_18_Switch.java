package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch4_18_Switch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age;
		System.out.println("Please Enter Age:");
		Scanner sc=new Scanner(System.in);
		age=sc.nextInt();
		
		switch(age) {
		case 18:
			System.out.println("you are going to become an adult");
			break;
		case 23:
			System.out.println("You are going to join a job!");
			break;
		case 60:
			System.out.println("You are going to get retired!");
			default:
				System.out.println("Enjoy your life!");
			
		}

		
		
	}

}
