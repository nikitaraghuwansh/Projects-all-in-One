package com.networking;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

	public static void main(String[] args) {

		try {
			ServerSocket sc=new ServerSocket(888);
			
			Socket SocketObject=sc.accept();
			
			System.out.println("Connection Accepeted");
			
			OutputStream os=SocketObject.getOutputStream();
			
			PrintStream ps=new PrintStream(os);
			
			ps.println("Hello");
			
			ps.println("Bye");
			
			ps.close();
			os.close();
			
			SocketObject.close();
			
		} catch (IOException e) {
			
			e.printStackTrace();
		}
		
	}

}
