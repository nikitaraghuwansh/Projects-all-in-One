package com.CodeWithHarry;

public class HarryQuetion1 {

	public static void main(String[] args) {
		float subject1 = 32;
		float Subject2 = 42;
		float subject3 = 54;
		System.out.println(subject1+Subject2+subject3/30);
		
		

	}

}
