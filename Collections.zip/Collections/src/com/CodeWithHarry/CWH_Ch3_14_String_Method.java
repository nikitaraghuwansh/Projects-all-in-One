package com.CodeWithHarry;

public class CWH_Ch3_14_String_Method {

	public static void main(String[] args) {
		/*
		 *   .length()
		 *   .toLowerCase()
		 *   .toupperCase() method 
		 *   .trim() method 
		 *   .substring method(int start)
		 *   .substring method(int start,int end)
		 *   .replace() method
		 *   .startsWith() method 
		 *   .endsWith() method
		 *   charAt() method
		 *   indexOf() method
		 *   .equals() method 
		 *   .equalsIgnoreCase() method
		 *   Escape Sequence Charector
		 */

		// .length() method String ki length check karne ke kamm aati h

		String name = "Nikita";

		String a1 = new String("Nikita Raghuwanshi");

		System.out.println(a1);

		int value = name.length();

		System.out.println(value);
		System.out.println(a1.length());
//---------------------------------------------------------------------------------------------

		// .toLowerCase() method Capital letter ko small kar deta h
		String tlower = "nIkItA";
		System.out.println(tlower.toLowerCase());
		// --------------------------------------------------------------------------------------

		// .toupperCase() method small letter ko capital kr deta h
		String tupper = "NIkiTa";
		System.out.println(tupper.toUpperCase());
//---------------------------------------------------------------------------------------------

		// trim() method space ko hta deta h jese ek string h " Nikita " ki space ko hta
		// dega Trim method
		String trimmed = "          Raghuwanshi          ";
		System.out.println(trimmed);

		String trimstring = trimmed.trim(); // new String banai
		System.out.println(trimmed.trim());
//---------------------------------------------------------------------------------------------------

		// substring method(int start) jese mene name="nikita" likh kr print me
		// name.Substring(2) likhungi to kita print hoga
		String Name = "Nikita";
		System.out.println(Name.substring(2));
//-----------------------------------------------------------------------------------------------------

		// //substring method(int start,int end) jese mene name="nikita" likh kr print
		// me name.Substring(2) likhungi to kita print hoga or agar name.substring(2,4)
		// likhungi kit print hoga
		String Name1 = "Nikita";
		System.out.println(Name1.substring(2, 5));
//---------------------------------------------------------------------------------------------------

		// replace() method char pr kam karta jese Harry me mujhe 'r' se 'p' ko replce
		// karna h to hum is method ka use karege,
		// yaha do charcter leta h ek oldChar or dusra newChar

		String str = "Harry";
		System.out.println(str.replace('r', 'p'));
		System.out.println(str.replace("rry", "ier"));
		System.out.println(str.replace("r", "ier"));
//----------------------------------------------------------------------------------------------------

		// .startsWith() method ye check karti jese mene nikita likha or mujhe ye check
		// karna h ki meri string ni ke start ho rahi h ya nhi to hum isi method ka use
		// karte h

		String swith = "nikita";
		System.out.println(swith.startsWith("ni"));
//-----------------------------------------------------------------------------------------------------

		// endsWith() method ye check karti jese mene nikita likha or mujhe ye check
		// karna h ki meri string ta se end ho rahi h ya nhi to hum isi method ka use
		// karte h
		String ewith = "nikita";
		System.out.println(ewith.endsWith("a"));
//-----------------------------------------------------------------------------------------------------

		// charAt() method jese mene nikita likha or mujhe chaek karna h ki (2)
		// number pr konsa char h to hum iska use kar sakte h String ki index 0 se start hoti h

		String charn="Raghuwanshi";
		System.out.println(charn.charAt(1));
//-------------------------------------------------------------------------------------------------------
		
		//indexOf() method yaha karta h jese ki mene nikita likha or mujhe check karna h ki k kis number pr h to is method ka use karte h
		 String iof="nikita";
		 System.out.println(iof.indexOf("k"));// string ki idex 0 se start hoti h
//--------------------------------------------------------------------------------------------------------
		 
		 //i`	ndexOf() method yaha karta h jese ki mene nikita likha or mujhe check karna h ki k kis number pr h to is method ka use karte h.
		 //match nhi milta to -1 aata h
		 String iof2="Harryrry";
		 System.out.println(iof2.indexOf("k"));// string ki idex 0 se start hoti h
	System.out.println(iof2.indexOf("rry", 4));
//-----------------------------------------------------------------------------------------------------------
	
	
	//lastindexof method jo last index h wo return karega, lastindexOf piche se khojta h ???????????????????????
	
	 String iof3="Harryrry";
	 System.out.println(iof3.indexOf("y"));// string ki idex 0 se start hoti h
System.out.println(iof2.indexOf("rry", 4));
//----------------------------------------------------------------------------------------------------------------

          //.equals() method  do value ko match  karne ke liye use karte h ki value same h ya nhi

String Name2="Java";
System.out.println(Name2.equals("Jav"));	

  
     //.equalsIgnoreCase() method case ko ingone kar deta h mtlb capital or small me farak nhi karta

System.out.println(Name2.equalsIgnoreCase("java"));	
//------------------------------------------------------------------------------------------------------------------

       //Escape Sequence Charector= kisi bhi String me Double quote " dalne ke liye use karte h \(backslash) lagte h kisibhi charector ko likhte h

System.out.println("I am escape sequence \" double qoute");
//------------------------------------------------------------------------------------------------------------------

         //
    
	}

}
