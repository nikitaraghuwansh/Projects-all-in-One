package com.networking;

import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server1 {

	public static void main(String[] args) throws IOException {
	
		ServerSocket sc=new ServerSocket(999);
		
		Socket SocketObject=sc.accept();
		
		System.out.println("Request Accepted");
		
		OutputStream os = SocketObject.getOutputStream();
		
		PrintStream ps= new PrintStream(os);
		
		ps.println("Hello");
		ps.println("Bye ");
		
		ps.close();
		sc.close();
		os.close();
		SocketObject.close();
		
		

	}

}
