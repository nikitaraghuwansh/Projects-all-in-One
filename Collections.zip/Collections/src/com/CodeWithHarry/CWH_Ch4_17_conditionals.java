package com.CodeWithHarry;

public class CWH_Ch4_17_conditionals {

	public static void main(String[] args) {
		System.out.println(" For logical AND......");
		boolean a = true;
		boolean b = false;
								// ek bhi condtion false hui to ye false hi aayega iska result
		if (a && b) {

			System.out.println("Y");
		}

		else
		{
			System.out.println("N");
		}
		
//-----------------------------------------------------------------------------------
		System.out.println("For logical OR...... ");
		
	boolean c=true;
	boolean d=false;
	
	
		if(c || d)
		{
			System.out.println("");
		}
	}
}
