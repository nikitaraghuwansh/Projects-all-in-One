package com.networking;

import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class URLConnectionClass {

	public static void main(String[] args) {

		try {
			URL url = new URL("http://www.google.com/index.html");

			URLConnection urcon = url.openConnection();

			System.out.println(urcon.getContentType());
			
			System.out.println(urcon.getPermission());
			
			System.out.println(urcon.getExpiration());
			
			System.out.println(urcon.getConnectTimeout());
			
			System.out.println(urcon.getAllowUserInteraction());
			
			System.out.println(urcon.getContentLength());
			
			System.out.println(urcon.getDate());
			
			System.out.println(urcon.getHeaderField(1));//??

		} catch (Exception e) {
			
			e.printStackTrace();
		}

	}

}
