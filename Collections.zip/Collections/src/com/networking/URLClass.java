package com.networking;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;

public class URLClass {

	public static void main(String[] args) {

		try {
			URL url = new URL("HTTPS://www.google.com/index.java");

			System.out.println("protocol is =" + url.getProtocol());//protocol means jaha se start hota h http ya https

			System.out.println("Port is = " + url.getPort());//
			
			System.out.println("Path is = " + url.getPath());//last me koi file hpti h waha path hoti h
			
			System.out.println("Host is = " + url.getHost());
		
			System.out.println("File is = " + url.getFile());
			
			System.out.println("Authority is = " + url.getAuthority());
			
			System.out.println("DefaultPort is = " + url.getDefaultPort());
			
			System.out.println("Query is = " + url.getQuery());
			
			System.out.println("UserInfo is = " + url.getUserInfo());
			
			System.out.println("Ref is = " + url.getRef());
			
			
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
