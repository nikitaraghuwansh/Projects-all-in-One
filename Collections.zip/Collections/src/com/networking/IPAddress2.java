package com.networking;

import java.net.*;
import java.util.Scanner;

public class IPAddress2 {

	public static void main(String[] args) {
		InetAddress inet=null;
		String inet2=null;
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter");
		inet2=sc.next();

		 try {
			inet=InetAddress.getByName(inet2);
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
	
	System.out.println(inet);
	}

}
