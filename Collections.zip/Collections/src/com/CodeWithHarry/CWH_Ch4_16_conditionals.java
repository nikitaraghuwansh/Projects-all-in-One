package com.CodeWithHarry;

public class CWH_Ch4_16_conditionals {

	public static void main(String[] args) {
	
		int age=27;
		
		boolean con=(age>18); // isme pahale hi condition de di
		
		if(con)
		{
			System.out.println("Yes You can drive!");
		}

		else
		{
			System.out.println("No You can not drive yet!");
		}
		
		
		
	}

}
