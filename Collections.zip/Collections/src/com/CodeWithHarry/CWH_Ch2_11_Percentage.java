package com.CodeWithHarry;

public class CWH_Ch2_11_Percentage {

	public static void main(String[] args) {
// 5 subject ke number leke percentage nikalna j
		// comments ka code dekha tha percentage nikalne ka

	}

}
