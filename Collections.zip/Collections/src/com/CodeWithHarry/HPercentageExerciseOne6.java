
/*Write a program to calculate percentage of a given 
student in CBSE board exam. His marks 5 sujects must be token as input from the keyboard
(marks are out of 100)*/


package com.CodeWithHarry;
import java.util.Scanner;

public class HPercentageExerciseOne6 {

	public static void main(String[] args) {
		
	int h,e,p,b,c,avg,total;
	String name;
	Scanner sc=new Scanner(System.in);
	
	System.out.println("Please Enter the Student name ");
	


name=sc.nextLine();

System.out.println(" Enter the Hindi Subject marks");
h=sc.nextInt();

System.out.println(" Enter the English Subject marks");
e=sc.nextInt();

System.out.println(" Enter the Physics Subject marks");
p=sc.nextInt();

System.out.println(" Enter the Biology Subject marks");
b=sc.nextInt();

System.out.println(" Enter the Chemistry Subject marks");
c=sc.nextInt();

total=h+e+p+b+c;
System.out.println("Total marks of : "+total);

avg=total/5;
System.out.println(" Parcentage is : "+avg);
	
	}

}
