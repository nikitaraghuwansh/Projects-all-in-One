package com.networking;

import java.sql.*;

public class Mysqlcon {

	public static void main(String[] args) throws Exception {
		Connection con = null;
		try {

			// Get Connection
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/school", "root", "1234");

			// Create Statement
			Statement stmt = con.createStatement();
			// Execute Query
			String query = "select * from student0";
			ResultSet rs = stmt.executeQuery(query);

			while (rs.next()) {
				System.out.println("class=" + rs.getString(1));
				System.out.println("Name=" + rs.getString(2));
				System.out.println("address=" + rs.getString(3));
				System.out.println("class=" + rs.getString(4));
				System.out.println("subjects=" + rs.getString(5));

			}

		} 

		finally {

			try {
				con.close();

			}

			catch (Exception e) {
			}

		}
	}

}
