package com.CodeWithHarry;

public class CWH_Ch2_Operators {

	public static void main(String[] args) {

		// Arthmetic Operator= +, -, *, /, %, ++, --
		int a = 20;
		int b = 10;
		int c;
		c = a + b;
		System.out.println(c);

		c = a - b;
		System.out.println(c);

		c = a * b;
		System.out.println(c);

		c = a / b;
		System.out.println(c);

		c = a % b;
		System.out.println(c);

		b += a;
		System.out.println(b);

		// ----------------------------------------------------------------------------------

//	Assignment Operater: =, +=
		b += a;
		System.out.println(b);

		// ------------------------------------------------------------------------------

		// Comparisor Operator: ==, >=, <=

		System.out.println(a == b);

		System.out.println(a > b);

		System.out.println(a <= b);// < jidhar iska muh khula hota h wo bada hota h
		System.out.println(20 > 10);

		// ----------------------------------------------------------------------------------

		// Logical Operator= &&, ||, !

		System.out.println(20 > 5 && 32 > 31);// Dono condition true honi chahiye

		System.out.println(20 > 5 || 32 > 34);// Ek true hona jaruri h

		// --------------------------------------------------------------------------------

		// Bitwise Operator= &, |

	}

}
