//1.Write java Program which calculate the Gross slary of employee
//Gross Salary=Basic Salary + HRA + Other Allowances

package com.salary;

import java.util.Scanner;

public class GrossSalary {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		double basic;
		System.out.println("enter the basic salary");
		basic = sc.nextInt();

		// HRA=12.5*basic salary
		//da=Other Allowances
		
		double da = basic * 30 / 100;
		double hra = basic * 12.5 / 100;
		double gp = basic + da + hra;
		System.out.println("gross salary = " + gp);

	}

}
