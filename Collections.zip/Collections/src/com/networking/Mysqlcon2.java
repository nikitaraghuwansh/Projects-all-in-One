package com.networking;
import java.sql.*;
public class Mysqlcon2 {

	public static void main(String[] args) throws Exception {
		
		Connection con=null;
		Statement stmt=null;
		ResultSet rs=null;
		//con=DriverManager.getConnection("jdbc:mysql://localhost:3306/grafix", "root","1234");
				try {
					con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Nikita", "root", "1234");
				} catch (Exception e) {
				
					e.printStackTrace();
				}
				try {
					 stmt= con.createStatement();
				} catch (Exception e) {

					e.printStackTrace();
				}

				String query = "select * from Grafix1";
				
				try {
					 rs= stmt.executeQuery(query);
				} catch (SQLException e) {
					
					e.printStackTrace();
				}			
				
				while(rs.next()) {
					System.out.println("class=" + rs.getString(1));
					
				}
				
	}

}
