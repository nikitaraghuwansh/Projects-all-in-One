package com.JDBC;

	import java.sql.*; //JDBC API

	class CreateTable {
		public static void main(String args[]) throws Exception {
			Connection con=null;
			try {
				//Class.forName("com.mysql.jdbc.Driver");

				con = DriverManager.getConnection("jdbc:mysql://localhost:3306/nikita", "root", "1234");

				Statement stmt = con.createStatement();

				String createTable = "create table student2(name varchar(100),id varchar(100))";

				int update = stmt.executeUpdate(createTable);
				System.out.println("update="+update);   
				
			} catch (Exception e) {
				System.out.println(e);
			}
			finally
			{
				con.close();
			}
		}
	}



