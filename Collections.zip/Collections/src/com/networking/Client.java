package com.networking;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) {

		try {
			try {
				Socket sc=new  Socket("Localhost",888);
				
				//need to read the data which is coming from server
				
				InputStream is=sc.getInputStream();
				
			InputStreamReader str=new InputStreamReader(is);
			
			BufferedReader br=new BufferedReader(str);
			
			String str1;
			
			while((str1=br.readLine())!=null)
			{
			System.out.println("Data from Server"+str1);
			}
			
			sc.close();//Socket ko close kr denge to sub close ho jayega
			
			br.close();
			
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		}
		
	}


