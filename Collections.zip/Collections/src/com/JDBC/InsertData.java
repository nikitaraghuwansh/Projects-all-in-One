
package com.JDBC;

import java.sql.*;
import java.sql.DriverManager;

import java.sql.Statement;

public class InsertData {

	public static void main(String[] args) {
		Connection con = null;

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysq", "root", "1234");

			Statement stmt = con.createStatement();

			String createTable = "insert into StudentInformation values('Manisha Raghuvanshi','manisha112@gmail.com','1001','9876543210','Virendra Singh','Indore')";
			int update = stmt.executeUpdate(createTable);
			System.out.println("update =" + update);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
