package com.HashSet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HMExample2 {

	public static void main(String[] args) {

		HashMap<String, Integer> hm = new HashMap<String, Integer>();

		hm.put("China", 150);
		hm.put("India", 130);
		hm.put("US", 30);
		System.out.println(hm);

		hm.put("China", 160);

		System.out.println(hm);
		
		hm.remove("China");

		// search
		if (hm.containsKey("China")) {
			System.out.println("Key is present in the HashMap");
		} else {
			System.out.println("Key is not present in tha hashMap");
		}
		
//		//get function
		
	 
}
}