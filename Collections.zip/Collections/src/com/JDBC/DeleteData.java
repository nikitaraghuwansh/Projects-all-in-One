package com.JDBC;

import java.sql.*;
import java.sql.DriverManager;

import java.sql.Statement;

public class DeleteData {

	public static void main(String[] args) {
		Connection con = null;

		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/Nikita", "root", "1234");

			Statement stmt = con.createStatement();

			String DeleteData = "delete from student2";
			int update = stmt.executeUpdate(DeleteData);
			System.out.println("update =" + update);

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
