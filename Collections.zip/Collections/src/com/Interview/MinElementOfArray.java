package com.Interview;

public class MinElementOfArray {

	public static void main(String[] args) {
		
	int [] arr=new int [] {48,4,910,18,5,1};
	
	int min=arr[0];
	
	for(int i=0;i<arr.length;i++) {
		
		if(arr[i]<min)
			min=arr[i];
			
	}
	System.out.println("Min Element of array: "+min);

	}

}
