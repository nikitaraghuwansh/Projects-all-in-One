// HashMap Unordar

package com.HashSet;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;


public class HMExample {

	public static void main(String[] args) 
	{
HashMap <String, String> hm=new HashMap<String, String>();

hm.put("9770385643","Nikita Raghuwanshi");
hm.put("9981784478", "Virendhra Raghuwanshi");
hm.put("8269445171", "Bulbul");
hm.put("8109800326", "Satyam");
hm.put("1234568521", "UnKnown Number");

hm.put("998178448","Virendhra Raghuwanshi");
System.out.println(hm);

//key ko search karna containsKey(Key ka name)
if(hm.containsKey("9981784478"))
{
	System.out.println("This Key contains hm");

}
else
{
	System.out.println(" this key Not Contain in hm");
}	
	
//	//get function
	System.out.println(hm.get("9770385643"));

	Set<String> keySet = hm.keySet();
	Iterator<String> it=keySet.iterator();
	
	while(it.hasNext())
	{
		String key=it.next();
		System.out.println(hm.get(key));
		
	}

	
	}

}
