package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch4_18_ElseIf {

	public static void main(String[] args) {
		int age;
		System.out.println("Enter age ");
		Scanner sc=new Scanner(System.in);
		age=sc.nextInt();
		                          //if else else if ladder
		
		if (age > 56) {
			System.out.println("You are experienced");
		}

		else if (age > 46) {
			System.out.println("You are semi experienced");

		}
		else if(age>36)
		{
			System.out.println("You are semi-semi-experienced");
		}
		
		else {
			System.out.println("You are not experienced");
		}
	}
}