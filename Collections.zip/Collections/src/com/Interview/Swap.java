
// Swap of two Number Without Using Third variable
package com.Interview;

import java.util.Scanner;

public class Swap {

	public static void main(String[] args) {
	
		int a,b;
		
		System.out.println("Enter any two Numbers ");
		Scanner sc=new Scanner (System.in);
		
		a=sc.nextInt();
		b=sc.nextInt();
		System.out.println("Before Swapping " +a+ "   "  +b);
		
		a=a+b;
		b=a-b;
		a=a-b;
		System.out.println("After Swapping " +a+ "   "  +b);
	}

}
