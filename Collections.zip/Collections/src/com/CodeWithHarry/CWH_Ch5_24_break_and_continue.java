package com.CodeWithHarry;

public class CWH_Ch5_24_break_and_continue {

	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			System.out.println(i);
			System.out.println("Java is  great!");

			if (i == 2) {
				System.out.println("Ending the Loop");
				break;// loop ko khatam karta h
			}

		}

		for (int x = 0; x < 5; x++) {
			System.out.println(x);
			System.out.println("Java is  great!");

			if (x == 2) {
				System.out.println("Ending the Loop");
				continue;// loop ko continue karta h

			}
		}
		System.out.println("Java is a Programming language");
	}
}
