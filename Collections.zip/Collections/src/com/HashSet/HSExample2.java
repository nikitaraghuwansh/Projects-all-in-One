package com.HashSet;

import java.util.HashSet;

public class HSExample2 {
	
	public static void main(String[] args) {
		
		HashSet <Integer> hs=new HashSet<Integer>();
		
		hs.add(1);
		hs.add(2);
		hs.add(3);
		hs.add(1);
		System.out.println(hs);
		
		hs.remove(1);

		
		if(hs.contains(1))
		{
			System.out.println("The 1 element contain in hs");
			
		}
		else 
		{
    System.out.println("Does not contain 1 in hs");
	}
		System.out.println("Size of hs"+hs.size());
  
			
}
}