package com.JDBC;

import java.sql.*;

public class CreateTable1 {

	public static void main(String[] args) {
		Connection con=null;
		
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306:/company","root","1234");
			
			Statement stmt=con.createStatement();
			
			String ceateTable="create table Employee (EmpName varchar(60), EmpId varchar(60),EmpPAN varchar(70)";
			
			int update=stmt.executeUpdate(ceateTable);
									
			System.out.println("Update="+update);
			
		} catch (Exception e) {
					e.printStackTrace();
					System.out.println("Update=");
		}
		
		finally {
			try {
				con.close();
			} catch (Exception e) {
				
				e.printStackTrace();
			}
		}
		

	}

}
