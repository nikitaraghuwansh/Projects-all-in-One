package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch4_19_PracticeSet4 {

	public static void main(String[] args) {
		// Question 1=

		/*
		 * int a = 10; if (a = 11) { System.out.println("I am 11"); } else {
		 * System.out.println("I am not a 11"); }
		 */
//---------------------------------------------------------------------------
		// Question 2
		int h, e, p, c, b;

		Scanner sc = new Scanner(System.in);
		System.out.println("Pleasse Enter the Hindi subject marks:");
		h = sc.nextInt();

		System.out.println("Please Enter The English Subject Marks:");
		e = sc.nextInt();

		System.out.println("Please Enter the Physics subject Mark:");
		p = sc.nextInt();

		float avg = (h + e + p) / 3;
		if (avg >= 40 && h >= 33 && e >= 33 && p >= 33) {
			System.out.println("Congratulations, You have been promoted");
		} else {
			System.out.println("Sorry You have not been promoted");
		}
//-----------------------------------------------------------------------------
		// Qurstion 3
		System.out.println("Enter Your Income");
		float tax = 0;
		float income = sc.nextFloat();
		;

		if (income < 2.5) {
			tax = tax + 0;

		} else if (income < 2.5 && income > 5f) {
			tax = tax + 0.05f * (5f - 2.5f);
		}

		else if (income < 2.5 && income > 5f) {
			tax = tax + 0.05f * (income - 2.5f);
		} else if (income > 10.0f) {
			tax = tax + 0.05f * (-2.5f);
			tax = tax + 0.2f * (10.0f - 5f);
			tax = tax + 0.3f * (income - 10.0f);
		}

		System.out.println("The total tax paid by the employee is:" + income);
//--------------------------------------------------------------------------------
		// Question-4
		System.out.println("Please Enter number:");
		int day = sc.nextInt();
		switch (day) {
		case 1:
			System.out.println("Monday");
			break;

		case 2:
			System.out.println("Tuesday");
			break;

		case 3:
			System.out.println("Wednesday");
			break;

		case 4:
			System.out.println("Thursday");
			break;

		case 5:
			System.out.println("Friday");
			break;

		case 6:
			System.out.println("Saturday");
			break;

		case 7:
			System.out.println("Sunday");
			break;

		}

//------------------------------------------------------------------------------------------
		// Question 5 = leap year
		/*System.out.println("Please Enter Year:");

		int year = sc.nextInt();

		if (year% 4 == 0) {
			System.out.println("THis is a leap year");
		}

		else {
			System.out.println("This is a not leap year");
		}*/
//-------------------------------------------------------------------------------------------
		//Ouestion 6
		System.out.println("Please Enter Website name");
		String website= sc.next();
		if(website.endsWith(".org"))
		{
			System.out.println("This is a organigation website");
		}
		else if(website.endsWith(".com"))
		{
			System.out.println("This is a commercial website");
		}
		else if(website.endsWith(".in"))
		{
			System.out.println("This is indian website");
		}
	}

}
