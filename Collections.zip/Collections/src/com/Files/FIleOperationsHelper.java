package com.Files;

import java.io.*;
import java.util.Scanner;

public class FIleOperationsHelper {
	Scanner sc = new Scanner(System.in);

//--------------------CreateFile-----------------------------------------------	
	public static void CreateFile1() {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter Your File Name...");
		String n = sc.nextLine();

		File f = new File(n);

		try {
			if (f.createNewFile())
			{
				System.out.println(" File Created....");
			}

			else
			{
				System.out.println("File not Created.....");
			}

		} catch (Exception e) {
			System.out.println(e);

		}

		// ----------------------------CopyFile-----------------------------------------

	}

	public static void CopyFile() {

		FileInputStream fis = null;
		FileOutputStream fos = null;
		Scanner sc = new Scanner(System.in);

		try {

			System.out.println("Name of Source File....");
			String s = sc.nextLine();

			System.out.println("Name of Destination File....");
			String d = sc.nextLine();

			fis = new FileInputStream(s);

			fos = new FileOutputStream(d);
			int c;

			while ((c = fis.read()) != -1) {
				fos.write((char) c);
			}
			System.out.println("n");
		} catch (IOException e1) {

			e1.printStackTrace();
		}

	}

//--------------------------DeleteFile-------------------------------------

	public static void DeleteFile() {
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter file name you want to Delete..");
			String x = sc.nextLine();
			File f = new File(x);

			if (f.delete()) {
				System.out.println("File Deleted.....");
			} else {
				System.out.println("File Not Deleted.....");
			}

		} catch (Exception e2) {
			System.out.println(e2);
		}

	}
//---------------------------DisplayFile-------------------------------------

	public static void DisplayFile() {

		FileInputStream fis = null;
		try {
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter file name you want to Display....");
			String z = sc.nextLine();

			fis = new FileInputStream(z);
			int ch;

			while ((ch = fis.read()) != -1) {
				System.out.print((char) ch);
			}
		} catch (IOException e3) {
			System.out.println(e3);
		}
		System.out.println(" ");

	}

//-----------------------------UpdateFile------------------------------------	
	public static void UpdateFile() {

		FileOutputStream fos = null;
		DataInputStream dis = null;

		Scanner sc = new Scanner(System.in);
		String v;
		System.out.println("Enter Your FileName you want to Display....  ");
		v = sc.nextLine();

		try {
			fos = new FileOutputStream(v);

			System.out.println("Input Your Data....  ");
			dis = new DataInputStream(System.in);

			char t;
			try {
				while ((t = (char) dis.read()) != '@') {
					fos.write(t);
				}
			} catch (IOException e) {

				System.out.println(e);
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}
//----------------------------------------------------------------

	/*
	 * FIleOperationsHelper
	 * 
	 * Methods- 1.Create File-File Name,Directory,COntent 2.Copy File(Backup)-Source
	 * File,Desination File 3.Search File-fileName to search 4.Delete File-fileName
	 * 5.Display Content of File?-fileName
	 * 
	 * 6.Update File?-fileName,Content
	 */

}
