package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch2_12_PracticeSet2_Q3 {

	public static void main(String[] args) {

		// Question3= use comperison operator to find out wether a given number is
		// greates than the user enterd number or not

		Scanner sc = new Scanner(System.in);
		int a = sc.nextInt();
		System.out.println(a > 8);// isse hum ye check kar sakte h ki ek given number se user define number bada h
									// ya chhota jese agar user ne to nuber enter kiya h wo 8 se bada h to true
									// aayega or agar chhota h to false aayega

	//-------------------------------------------------------------------------------------------------------------
		//Question4=write the following expressio in a java program
		
	//	v2-u2
	//---------
	//	2a5
		float v=(float) 21.0;
		float u=(float) 4.0;
		float e= (float) 8.0;
		
		
		float x=(int) ((v*v-u*u)/(2*e*5));
		System.out.println(x);
	//---------------------------------------------------------------------------------------------------------------
		
		//Question5=find the value of the following expression:
	/*	int r=7;
		int i=7*49/7+35/7; 
		//sabse phale 7*49 ka mutiplication hoga or result 49 aayega fir 35/7 hoga or 5 result aayega fir 49+5 hoga
		
		*/
		int r=7;
		int i=7*49 / 7+35 /7;
		System.out.println(i);
		
		
	
	
	
	
	
	
	
	}

}
