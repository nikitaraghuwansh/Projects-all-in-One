package com.JDBC;

import java.sql.*;
import java.sql.Statement;

public class JdbcMysql {

	public static void main(String[] args) {
		
		//Get Connection
		try {
		Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306://Grafix1","root","1234");
		
		//Create the Statement
		
		Statement stmt = con.createStatement();
		
		
		//Execute Query
		String query = "select * from student";
		
		ResultSet rs = stmt.executeQuery(query);
		
	} catch (Exception e) {
		e.printStackTrace();
	}


}
}