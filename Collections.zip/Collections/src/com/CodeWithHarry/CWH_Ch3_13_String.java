package com.CodeWithHarry;

import java.util.Scanner;

public class CWH_Ch3_13_String {

	public static void main(String[] args) {
		
		String name=new String("Nikita"); //Object
		String str="Raghuwanshi";		
		
		System.out.println(name);
		System.out.println(str);
		//--------------------------------------------------------------------------------
		
		int a=6;
		float b=5.6454f;
		
		System.out.printf("The value of a is %d and value of b is %f",a,b);
		
		//format specifire|| %d int ke liye %f float ke liye 
	//%d double ke liye %s String ke liye %c chaercter ke liye
		
		System.out.format("The value of a is %d and value of b is %f",a,b);
		
		Scanner sc=new Scanner(System.in);
		//String ar=sc.next();
		
		System.out.println("Enter string");
		
		String ar=sc.nextLine();
		
		
		System.out.println(ar);
	
		
		
	}

}
