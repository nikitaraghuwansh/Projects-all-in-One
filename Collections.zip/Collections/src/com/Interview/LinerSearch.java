package com.Interview;

public class LinerSearch {

	public static void main(String[] args) {

		int [] arr= {3,35,43,6,46,7,8};
		int item=7 ;
		for(int i=0;i<arr.length;i++)
		{
			
			if(arr[i]==item)
			{
				System.out.println("item is present at  "+i+"  index position");
			}
		}
	}

}
