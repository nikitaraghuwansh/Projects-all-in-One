package com.Interview;

public class MaxElementOfArray {

	public static void main(String[] args) {
		
		
		int [] arr = new int [] {32,46,76,88,87,78}; 
		
		int max=arr[0];
		for(int i=0;i<arr.length;i++)
		{
		if (arr[i]>max)
		{
			max=arr[i];
			
		}
			
		}
		System.out.println(max);
	}

}
