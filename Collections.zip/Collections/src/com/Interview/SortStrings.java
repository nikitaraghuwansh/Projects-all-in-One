package com.Interview;

import java.util.Scanner;

public class SortStrings {

	public static void main(String[] args) {
	
		String temp;
		System.out.println("Enter the value of N:");
		int N;
		Scanner sc=new Scanner(System.in);
		N=sc.nextInt();
		sc.nextLine();//ignore next line character
		
		String names[]=new String [N];
		System.out.println("Enter Names: ");
		
		for(int i=0;i<=N;i++) {
			System.out.println("Enter Name" + (i+1)+ "]:");
		}
		
	}

}
