package com.Interview;

import java.util.Scanner;
public class ReverseString {

	public static void main(String[] args) {
	
		
	int number=0;
	Scanner sc=new Scanner (System.in);
	System.out.println("Enter Your Number");
	number=sc.nextInt();
	
	int reverse=0;
	
	while(number>0) {
		
		reverse=number%10;
		
		System.out.println("Reverse No is = "+reverse);
		number=number/10;
		
	}
	}

}
