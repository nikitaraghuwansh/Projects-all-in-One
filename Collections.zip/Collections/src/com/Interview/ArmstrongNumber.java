package com.Interview;

import java.util.Scanner;

public class ArmstrongNumber {

	public static void main(String[] args) {
		int number,arm =0;
		int remender;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Your Number:");
		number=sc.nextInt();
		int c=number;
		
		while(number>0) {
			 remender = number%10;
		arm=(remender*remender*remender)+arm;
		number= number/10;
			
		}
		if(c==arm) {
			System.out.println("Armstrong number");
		}
		else {
			System.out.println("not Armstrong number");
		}
		
		
	}

}




