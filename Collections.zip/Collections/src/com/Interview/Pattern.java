package com.Interview;

public class Pattern {

	public static void main(String[] args) {
		int number = 5;
		System.out.println("## Printing the pattern ##");
		
		for (int i = 1; i <= number; i++) {
			
			for (int j = 1; j <= i; j++) {
				
				System.out.print("*" + " ");
			}
			System.out.println();
		}
	}
}
