package com.Files;

import java.io.File;
import java.util.Scanner;

class CreateFile {
	private void CreateFile1() {

		Scanner sc = new Scanner(System.in);
		String n = sc.nextLine();

		File f = new File(n);

		try {
			if (f.createNewFile()) {
				System.out.println("Successfully");
			}

			else {
				System.out.println("false");
			}

		} catch (Exception e) {
			System.out.println(e);

		}
	}
}
