package com.JDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class UpdateData {

	public static void main(String[] args) {
		Connection con = null;
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306:/Nikita", "root", "1234");
			Statement stmt = con.createStatement();

			String query = "update student set Name = Mona , where ID=1001";
			stmt.executeUpdate(query);

			// PreparedStatement pstmt=con.prepareStatement(query);

			// pstmt.setString(1001, Name);

			// System.out.println(update);

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
