package com.CodeWithHarry;

public class CWH_Ch5_22_do_while {

	public static void main(String[] args) {
		int b = 10;
		do {
			System.out.println(b);
			b++;
		} while (b < 5);
//--------------------------------------------------------------------
		//Quick Quig= WAP to print first n natural number using do while loop
		int c = 1;
		do {
			System.out.println(c);
			c++;
		}while(c<=40);
	}
}
