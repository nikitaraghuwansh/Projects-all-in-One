package com.CodeWithHarry;

public class CWH_Ch2_12_precticeSet2 {

	public static void main(String[] args) {
		// Question1= what will be the result of the following expression
		// float a=7/4*9/2

		float a = 7 / 4f * 9 / 2f;

		// isme aisa ho rraha pahale to 7/4 ho raha iska result aa rraha 1.75 fir uske
		// baad 1.75 ka * hoga 9 me
		// fir iske result se 2 se /devide hoga

		System.out.println(a);
		// --------------------------------------------------------------------------------------------------------------

		// Question2= Write a java program to encrept a grade by adding 8 to it. Decrept
		// it to show the corect grade
		char grade = 'B';
		char grade1 = 'J';
		grade = (char) (grade + 8); // Incement. Yaha pr jo ye (char) lga h ye humne type casting ki h

		grade1= (char) (grade1 - 8);// Decrement
		System.out.println(grade);
		System.out.println(grade1);
//----------------------------------------------------------------------------------------------------------------------
		
		
		
	}
}
