package com.Client;

import com.Files.FIleOperationsHelper;
import java.util.Scanner;

public class Client {
	public static void main(String args[]) {

		Scanner sc=new Scanner(System.in);
		
		System.out.println("if you Enter 1 then Create File..");
		System.out.println("if you Enter 2 then Delete File..");
		System.out.println("if you Enter 3 then Display File..");
		System.out.println("if you Enter 4 then Copy File..");
		System.out.println("if you Enter 5 then Update File..");
		System.out.println("Enter Your Number..");
		
		
		int y=sc.nextInt();
		FIleOperationsHelper N = new FIleOperationsHelper();
		switch (y)
		{
		
		case 1:
			N.CreateFile1();
			break;
			
		case 2:
			N.DeleteFile();
			break;
			
		case 3:
			N.DisplayFile();
			break;
		case 4:
			
			  N.CopyFile();
			  break;
			  
		case 5:
			N.UpdateFile();
			break;
			
			default:
				System.out.println("Please Enter Valid Number.....");
		}
		
		
		/*N.CreateFile1();
		
		N.DeleteFile();
		
		N.DisplayFile();
		
	    N.CopyFile();
	    
		N.UpdateFile();*/
	}

}
