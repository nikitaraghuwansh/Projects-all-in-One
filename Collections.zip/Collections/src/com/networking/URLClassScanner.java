package com.networking;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class URLClassScanner {

	public static void main(String[] args) {
		String urll = null;
		System.out.println("Enter ");
		Scanner sc = new Scanner(System.in);
		urll = sc.next();
		
		
		try {
			URL url = new URL(urll);
		} catch (MalformedURLException e) {

			e.printStackTrace();
		}

	
		System.out.println(urll);
		System.out.println(urll);

	}

}
