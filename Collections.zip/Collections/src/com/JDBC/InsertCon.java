/*
 * package com.JDBC;
 * 
 * import java.sql.Connection; import java.sql.DriverManager; import
 * java.sql.ResultSet; import java.sql.SQLException;
 * 
 * public class InsertCon {
 * 
 * public static void main(String[] args) throws Exception { // get connection
 * Connection con = null; try { con =
 * DriverManager.getConnection("jdbc:mysql://localhost:3306://Grafix1", "root",
 * "1234"); } catch (SQLException e) {
 * 
 * e.printStackTrace(); }
 * 
 * // create statement java.sql.Statement stmt = con.createStatement();
 * 
 * // string query //String query =
 * ("insert into grafix1 values('Mona','103','B.com');");
 * 
 * String query="select * form grafix1";
 * 
 * ResultSet rs=stmt.executeQuery(query);
 * 
 * while (rs.next()) {
 * 
 * System.out.println(rs.getString(1)); System.out.println(rs.getString(2));
 * System.out.println(rs.getString(3)); }
 * 
 * finally {
 * 
 * con.close();
 * 
 * }
 * 
 * } }
 */