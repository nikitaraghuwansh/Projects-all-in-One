package com.Interview;

import java.util.*;

public class Display_Odd_Number8 {

	public static void main(String args[]) {
		int n;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter No of Range");
		n = sc.nextInt();

		for (int i = 1; i <= n; i = i + 2) {
			System.out.println(i);
		}
	}

}
